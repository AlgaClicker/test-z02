<?php return array (
  'inertiajs/inertia-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Inertia\\ServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'movemoveapp/laravel-dadata' => 
  array (
    'aliases' => 
    array (
      'DaDataBank' => 'MoveMoveIo\\DaData\\Facades\\DaDataBank',
      'DaDataName' => 'MoveMoveIo\\DaData\\Facades\\DaDataName',
      'DaDataEmail' => 'MoveMoveIo\\DaData\\Facades\\DaDataEmail',
      'DaDataPhone' => 'MoveMoveIo\\DaData\\Facades\\DaDataPhone',
      'DaDataAddress' => 'MoveMoveIo\\DaData\\Facades\\DaDataAddress',
      'DaDataCompany' => 'MoveMoveIo\\DaData\\Facades\\DaDataCompany',
      'DaDataPassport' => 'MoveMoveIo\\DaData\\Facades\\DaDataPassport',
    ),
    'providers' => 
    array (
      0 => 'MoveMoveIo\\DaData\\DaDataServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
  ),
);