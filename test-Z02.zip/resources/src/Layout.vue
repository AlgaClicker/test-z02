<script setup>
import { Link } from '@inertiajs/vue3'
</script>
<template>
    <main>
        <header>
            <nav class="navigation-menu">
                <ul class="menu-list">
                    <!-- Перебор пунктов меню -->
                    <li v-for="link in linksItems"  :key="link.name" class="menu-item">
                        <!-- Кнопка-триггер для показа выпадающего меню -->
                        <Link :href="link.href" v-show="link.isAuth === getIsAuth">
                            <button v-show="!link.submit"   class="menu-trigger">  {{ link.text }} {{link.show }}</button>
                            <button  v-show="link.submit" @click="link.submit" class="menu-trigger">  {{ link.text }}</button>
                        </Link>
                    </li>
                </ul>
            </nav>

        </header>
        <article>
            <slot />
        </article>
    </main>
</template>

<script>


import {router, usePage, Deferred} from "@inertiajs/vue3";
import { useAuthStore } from './store/'
import { mapState,mapActions } from 'pinia'

export default {
    components: {router},
    props: {
        account: Object,
    },
    data() {
        return {
            linksItems : [
                {
                    name: "home",
                    text:"Главная",
                    href: '/home',
                    isAuth: true
                },
                {
                    name: "about",
                    text:"Описание",
                    href: 'about/',
                    isAuth: true
                },
                {
                    name: "counteragents",
                    text:"Контрагенты",
                    href: '/counteragents',
                    isAuth: true
                },
                {
                    name: "info",
                    text:"Инфо PHP",
                    href: '/info',
                    isAuth: true
                },
                {
                    name: "loginout",
                    text:"Завершить сеанс",
                    href: '/loginout',
                    isAuth: true,
                    submit: this.loginout
                },
            ],
        }
    },
    mounted() {

        this.setPage(usePage().url)
    },
    async created() {

        await this.checkAuth()

    },
    methods: {
        ...mapActions(useAuthStore,['checkAuth','setPage']),
        loginout() {
            console.log("loginout")
            localStorage.setItem('auth_token',"")
            router.get("/")
        },

    },
    computed: {
        ...mapState(useAuthStore,['getIsAuth','getAccount']),
        isAuth() {
            return this.getIsAuth;
        }
    },


}
</script>

<style scoped>
.navigation-menu {
    /* Стилизация основного контейнера */
}

.menu-list {
    display: flex;
    list-style: none;
    gap: 1rem;
    padding: 0;
}

.menu-item {
    position: relative;
}

.menu-trigger {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1rem;
}

.menu-content {
    position: absolute;
    top: 100%;
    left: 0;
    background: white;
    border: 1px solid #ddd;
    padding: 0.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    z-index: 10;
}

.menu-link {
    display: block;
    padding: 0.25rem 0.5rem;
    text-decoration: none;
    color: inherit;
}

.menu-link:hover {
    background-color: #f0f0f0;
}
</style>
